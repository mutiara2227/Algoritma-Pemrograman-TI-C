buku = [['Algoritma',2000],['Basis Data',2500],['Struktur Data',3000],['Aljabar',4000],['Statistika',1000]]

print('DAFTAR BUKU CERDAS ILMU')

for i in range(len(buku)):
    print(i+1,'.',buku[i][0], ':', buku[i][1])

pilih = int(input('Masukkan nomor buku : '))

if pilih >= 1 and pilih <= len(buku):
    judul = buku[pilih-1][0]
    denda = buku[pilih-1][1]
    print('Buku yang dipilih : ',judul)
    print('Denda per hari : ',denda)
else:
    print('Error: Nomor tidak valid!')