buku = [['Algoritma',2000],['Basis Data',2500],['Struktur Data',3000],['Aljabar',4000],['Statistika',1000]]

peminjaman =[]

print('DAFTAR BUKU CERDAS ILMU')

for i in range(len(buku)):
    print(i+1,'.',buku[i][0], ':', buku[i][1])

while True:
    pilih = int(input('Masukkan nomor buku yg mau dipinjam (0 untuk selesai pilih): '))

    if pilih == 0:
        break
    
    if pilih >= 1 and pilih <= len(buku):
        judul = buku[pilih-1][0]
        denda = buku[pilih-1][1]
    
        lama_pinjam = int(input('Berapa hari pinjam : '))
        peminjaman.append([judul, denda, lama_pinjam])
    
        print('Buku yang dipilih : ',judul)
        print('Lama peminjaman : ',lama_pinjam,'hari')

    else:
        print('Error: Nomor tidak valid!')

print('\nDAFTAR PEMINJAMAN BUKU')
total_denda = 0
for x in peminjaman:
    judul = x[0]
    denda = x[1]
    lama_pinjam = x[2]
    denda_sementara = denda*lama_pinjam

    print(judul, '(', lama_pinjam,'hari ) =', denda_sementara)
    total_denda += denda_sementara

print('Total Denda (Lambat 1 hari) : ',total_denda)


